#include "simulate.h"
#include "pqueue.h"
void simulate_srt() {
    
}