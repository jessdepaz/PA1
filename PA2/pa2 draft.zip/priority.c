#include "simulate.h"
#include "queue.h"
void simulate_priority_rr() {
    
}